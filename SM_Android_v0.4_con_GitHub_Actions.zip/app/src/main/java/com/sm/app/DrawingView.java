package com.sm.app;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

public class DrawingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Bitmap bitmap;
    private Canvas canvas;

    public DrawingView(Context context, android.util.AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(Color.rgb(30,30,30));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(9f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    private void ensureBitmap() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        if (bitmap == null || bitmap.getWidth()!=getWidth() || bitmap.getHeight()!=getHeight()) {
            bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(Color.WHITE);
            canvas = new Canvas(bitmap);
        }
    }

    @Override protected void onDraw(Canvas c) {
        ensureBitmap();
        if (bitmap != null) c.drawBitmap(bitmap, 0, 0, null);
        c.drawPath(path, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        ensureBitmap();
        float x=e.getX(), y=e.getY();
        switch(e.getAction()) {
            case MotionEvent.ACTION_DOWN: path.moveTo(x,y); invalidate(); return true;
            case MotionEvent.ACTION_MOVE: path.lineTo(x,y); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                path.lineTo(x,y);
                if (canvas != null) canvas.drawPath(path, paint);
                path.reset(); invalidate(); return true;
        }
        return true;
    }

    public void clear() {
        ensureBitmap();
        if (canvas != null) { canvas.drawColor(Color.WHITE); path.reset(); invalidate(); }
    }

    public Bitmap getBitmap() { ensureBitmap(); return bitmap; }

    public void setBitmap(Bitmap b) {
        if (b == null) return;
        bitmap = b.copy(Bitmap.Config.ARGB_8888, true);
        canvas = new Canvas(bitmap);
        invalidate();
    }
}
