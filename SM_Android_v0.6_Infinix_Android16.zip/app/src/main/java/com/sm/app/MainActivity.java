package com.sm.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.WindowManager;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    /*
     * IMPORTANT:
     * Put the public HTTPS address of your deployed S M server here.
     * Example: https://sm-tu-servidor.example.com
     */
    private static final String BASE_URL = "https://sm-servidor.onrender.com";

    private static final int NOTIF = 10;
    private DrawingView drawing;
    private TextView status;
    private ScheduledExecutorService poller;
    private String myCode;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        setContentView(R.layout.activity_main);

        drawing = findViewById(R.id.drawingView);
        status = findViewById(R.id.status);
        EditText partnerCode = findViewById(R.id.partnerCode);
        TextView myCodeView = findViewById(R.id.myCode);

        myCode = getSharedPreferences("sm", MODE_PRIVATE).getString("my_code", null);
        if (myCode == null) {
            int n = new Random().nextInt(900000) + 100000;
            myCode = "SM-" + String.format(Locale.US, "%06d", n);
            getSharedPreferences("sm", MODE_PRIVATE).edit().putString("my_code", myCode).apply();
        }
        myCodeView.setText(myCode);

        String savedPartner = getSharedPreferences("sm", MODE_PRIVATE)
                .getString("partner_code", "");
        partnerCode.setText(savedPartner);

        findViewById(R.id.linkButton).setOnClickListener(v -> {
            String other = partnerCode.getText().toString().trim().toUpperCase(Locale.US);
            if (!other.matches("SM-[0-9]{6}") || other.equals(myCode)) {
                status.setText("Revisa el código de tu pareja.");
                return;
            }
            status.setText("Conectando...");
            postJson("/link",
                    "{\"myCode\":\"" + myCode + "\",\"partnerCode\":\"" + other + "\"}",
                    response -> {
                        getSharedPreferences("sm", MODE_PRIVATE).edit()
                                .putString("partner_code", other).apply();
                        status.setText("❤️ ¡Pareja vinculada!");
                    },
                    error -> status.setText("No se pudo conectar: " + error));
        });

        findViewById(R.id.lockSettingsButton).setOnClickListener(v -> openLockSettings());

        findViewById(R.id.testButton).setOnClickListener(v -> {
            status.setText("Probando servidor...");
            getJson("/health",
                    response -> status.setText("☁️ Servidor S M conectado."),
                    error -> status.setText("Servidor no disponible: " + error));
        });

        findViewById(R.id.clearButton).setOnClickListener(v -> drawing.clear());
        findViewById(R.id.sendButton).setOnClickListener(v -> sendDrawing());

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIF);
        }

        updateLockStatus();
        startPolling();
    }

    private void openLockSettings() {
        // En Android 16 / XOS (como en este teléfono), no existe un permiso
        // único llamado "permiso de pantalla de bloqueo". S M abre los ajustes
        // oficiales que sí controlan esta experiencia.
        new AlertDialog.Builder(this)
                .setTitle("Configurar S M 🔒")
                .setMessage("Primero activa el permiso de mostrar sobre otras apps. Después puedes revisar las notificaciones de S M para permitir que aparezcan con la pantalla bloqueada. Android seguirá protegiendo el PIN, patrón o huella.")
                .setPositiveButton("Mostrar sobre otras apps", (d, w) -> openOverlaySettings())
                .setNeutralButton("Notificaciones", (d, w) -> openNotificationSettings())
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (Exception ignored) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }

    private void openNotificationSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void updateLockStatus() {
        TextView lockStatus = findViewById(R.id.lockStatus);
        if (Build.VERSION.SDK_INT >= 23) {
            lockStatus.setText(Settings.canDrawOverlays(this)
                    ? "🔒 Pantalla S M: permiso activado"
                    : "🔒 Pantalla S M: activa el permiso en Ajustes");
        } else {
            lockStatus.setText("🔒 Funciones de pantalla disponibles");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (lockStatusExists()) updateLockStatus();
    }

    private boolean lockStatusExists() {
        return findViewById(R.id.lockStatus) != null;
    }

    private void sendDrawing() {
        Bitmap b = drawing.getBitmap();
        if (b == null) return;

        // Reduce el tamaño para que el dibujo viaje rápido.
        Bitmap small = Bitmap.createScaledBitmap(b, Math.min(900, b.getWidth()),
                Math.min(900, b.getHeight()), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        small.compress(Bitmap.CompressFormat.JPEG, 80, out);
        String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);

        status.setText("Enviando ❤️...");
        String json = "{\"myCode\":\"" + myCode +
                "\",\"kind\":\"drawing\",\"data\":\"data:image/jpeg;base64," + encoded + "\"}";

        postJson("/message", json,
                response -> status.setText("❤️ Dibujo enviado."),
                error -> status.setText("No se pudo enviar: " + error));
    }

    private void startPolling() {
        poller = Executors.newSingleThreadScheduledExecutor();
        poller.scheduleWithFixedDelay(() -> getJson("/message?code=" +
                URLEncoder.encode(myCode, StandardCharsets.UTF_8),
                response -> {
                    try {
                        if (response.contains("\"message\":null")) return;
                        int dataStart = response.indexOf("\"data\":\"");
                        if (dataStart < 0) return;
                        dataStart += 8;
                        int end = response.lastIndexOf("\"}");
                        if (end <= dataStart) return;
                        String data = response.substring(dataStart, end)
                                .replace("\\/", "/").replace("\\\"", "\"");
                        int comma = data.indexOf("base64,");
                        if (comma < 0) return;
                        byte[] bytes = Base64.decode(data.substring(comma + 7), Base64.DEFAULT);
                        Bitmap received = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        runOnUiThread(() -> {
                            if (received != null) {
                                drawing.setBitmap(received);
                                status.setText("💌 Recibiste un dibujo.");
                            }
                        });
                    } catch (Exception ignored) {}
                }, error -> {}), 2, 5, TimeUnit.SECONDS);
    }

    private void getJson(String path, java.util.function.Consumer<String> ok,
                         java.util.function.Consumer<String> fail) {
        Executors.newSingleThreadExecutor().execute(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE_URL + path);
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                int code = c.getResponseCode();
                String body = read(c, code >= 400 ? c.getErrorStream() : c.getInputStream());
                if (code >= 400) throw new IOException(body);
                runOnUiThread(() -> ok.accept(body));
            } catch (Exception e) {
                runOnUiThread(() -> fail.accept(e.getMessage() == null ? "error" : e.getMessage()));
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private void postJson(String path, String json, java.util.function.Consumer<String> ok,
                          java.util.function.Consumer<String> fail) {
        Executors.newSingleThreadExecutor().execute(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE_URL + path);
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setDoOutput(true);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                String body = read(c, code >= 400 ? c.getErrorStream() : c.getInputStream());
                if (code >= 400) throw new IOException(body);
                runOnUiThread(() -> ok.accept(body));
            } catch (Exception e) {
                runOnUiThread(() -> fail.accept(e.getMessage() == null ? "error" : e.getMessage()));
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private String read(HttpURLConnection c, InputStream in) throws IOException {
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder s = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) s.append(line);
            return s.toString();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (poller != null) poller.shutdownNow();
    }
}
