package com.sm.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.*;
import android.util.Base64;
import android.view.WindowManager;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String BASE_URL = "https://sm-servidor.onrender.com";
    private static final int NOTIF = 10, CAMERA = 11, PICK_IMAGE = 12, TAKE_PHOTO = 13;
    private DrawingView drawing;
    private TextView status;
    private ScheduledExecutorService poller;
    private String myCode;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        setContentView(R.layout.activity_main);
        drawing = findViewById(R.id.drawingView);
        status = findViewById(R.id.status);
        EditText partnerCode = findViewById(R.id.partnerCode);
        TextView myCodeView = findViewById(R.id.myCode);
        myCode = getSharedPreferences("sm", MODE_PRIVATE).getString("my_code", null);
        if (myCode == null) {
            int n = new Random().nextInt(900000) + 100000;
            myCode = "SM-" + String.format(Locale.US, "%06d", n);
            getSharedPreferences("sm", MODE_PRIVATE).edit().putString("my_code", myCode).apply();
        }
        myCodeView.setText(myCode);
        partnerCode.setText(getSharedPreferences("sm", MODE_PRIVATE).getString("partner_code", ""));

        findViewById(R.id.linkButton).setOnClickListener(v -> {
            String other = partnerCode.getText().toString().trim().toUpperCase(Locale.US);
            if (!other.matches("SM-[0-9]{6}") || other.equals(myCode)) { status.setText("Revisa el código de tu pareja."); return; }
            status.setText("Conectando...");
            postJson("/link", "{\"myCode\":\""+myCode+"\",\"partnerCode\":\""+other+"\"}", r -> {
                getSharedPreferences("sm", MODE_PRIVATE).edit().putString("partner_code", other).apply();
                status.setText("❤️ ¡Pareja vinculada!");
            }, e -> status.setText("No se pudo conectar: " + e));
        });
        findViewById(R.id.testButton).setOnClickListener(v -> { status.setText("Probando servidor..."); getJson("/health", r -> status.setText("☁️ Servidor S M conectado."), e -> status.setText("Servidor no disponible: "+e)); });
        findViewById(R.id.lockSettingsButton).setOnClickListener(v -> openLockSettings());
        findViewById(R.id.clearButton).setOnClickListener(v -> drawing.clear());
        findViewById(R.id.sendButton).setOnClickListener(v -> sendDrawing());
        findViewById(R.id.photoButton).setOnClickListener(v -> pickImage());
        findViewById(R.id.cameraButton).setOnClickListener(v -> takePhoto());
        findViewById(R.id.textButton).setOnClickListener(v -> addText());

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIF);
        updateLockStatus();
        startPolling();
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i, PICK_IMAGE);
    }

    private void takePhoto() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CAMERA"}, CAMERA); return;
        }
        try { startActivityForResult(new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE), TAKE_PHOTO); }
        catch (Exception e) { status.setText("No se pudo abrir la cámara."); }
    }

    private void addText() {
        final EditText input = new EditText(this);
        input.setHint("Escribe tu mensaje");
        new AlertDialog.Builder(this).setTitle("✍️ Escribir").setView(input)
            .setNegativeButton("Cancelar", null).setPositiveButton("Poner en la imagen", (d,w) -> {
                String text = input.getText().toString().trim();
                if (!text.isEmpty()) drawing.addText(text);
            }).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            Bitmap b = null;
            if (requestCode == PICK_IMAGE && data.getData() != null) b = android.provider.MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
            if (requestCode == TAKE_PHOTO && data.getExtras() != null) b = (Bitmap)data.getExtras().get("data");
            if (b != null) { drawing.setBitmap(b); status.setText("🖼️ Imagen lista. Puedes dibujar o escribir encima."); }
        } catch (Exception e) { status.setText("No se pudo cargar la imagen."); }
    }

    private void openLockSettings() {
        new AlertDialog.Builder(this).setTitle("Configurar S M 🔒")
            .setMessage("S M usa las funciones oficiales de Android para intentar mostrarse cuando se enciende la pantalla. También puedes activar notificaciones en la pantalla bloqueada. Android seguirá protegiendo tu PIN, patrón o huella.")
            .setPositiveButton("Notificaciones", (d,w) -> openNotificationSettings())
            .setNeutralButton("Sobre otras apps", (d,w) -> openOverlaySettings()).setNegativeButton("Cerrar", null).show();
    }
    private void openOverlaySettings() {
        try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
        catch(Exception e){ try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); } catch(Exception ignored){ startActivity(new Intent(Settings.ACTION_SETTINGS)); } }
    }
    private void openNotificationSettings() {
        try { Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS); i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()); startActivity(i); }
        catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }
    private void updateLockStatus() { ((TextView)findViewById(R.id.lockStatus)).setText("🔒 S M está preparado para mostrarse al encender la pantalla (según las reglas de Android/XOS)"); }

    private void sendDrawing() {
        Bitmap b = drawing.getBitmap(); if (b == null) return;
        int max = 1000; float scale = Math.min(1f, max / (float)Math.max(b.getWidth(), b.getHeight()));
        Bitmap small = scale < 1f ? Bitmap.createScaledBitmap(b, Math.max(1,(int)(b.getWidth()*scale)), Math.max(1,(int)(b.getHeight()*scale)), true) : b;
        ByteArrayOutputStream out = new ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG, 82, out);
        String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        status.setText("Enviando ❤️...");
        String json = "{\"myCode\":\""+myCode+"\",\"kind\":\"image_text_drawing\",\"data\":\"data:image/jpeg;base64,"+encoded+"\"}";
        postJson("/message", json, r -> status.setText("❤️ Mensaje enviado."), e -> status.setText("No se pudo enviar: "+e));
    }

    private void startPolling() {
        poller = Executors.newSingleThreadScheduledExecutor();
        poller.scheduleWithFixedDelay(() -> getJson("/message?code="+URLEncoder.encode(myCode, StandardCharsets.UTF_8), response -> {
            try {
                if (response.contains("\"message\":null")) return;
                int ds=response.indexOf("\"data\":\""); if(ds<0)return; ds+=8; int end=response.lastIndexOf("\"}"); if(end<=ds)return;
                String data=response.substring(ds,end).replace("\\/","/").replace("\\\"","\""); int comma=data.indexOf("base64,"); if(comma<0)return;
                byte[] bytes=Base64.decode(data.substring(comma+7),Base64.DEFAULT); Bitmap received=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                runOnUiThread(() -> { if(received!=null){ drawing.setBitmap(received); status.setText("💌 Recibiste un mensaje de tu pareja."); } });
            } catch(Exception ignored){}
        }, e -> {}), 2, 5, TimeUnit.SECONDS);
    }

    private void getJson(String path, java.util.function.Consumer<String> ok, java.util.function.Consumer<String> fail) {
        Executors.newSingleThreadExecutor().execute(() -> { HttpURLConnection c=null; try { URL u=new URL(BASE_URL+path); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(8000); c.setReadTimeout(8000); int code=c.getResponseCode(); String body=read(c,code>=400?c.getErrorStream():c.getInputStream()); if(code>=400)throw new IOException(body); runOnUiThread(()->ok.accept(body)); } catch(Exception e){runOnUiThread(()->fail.accept(e.getMessage()==null?"error":e.getMessage()));} finally{if(c!=null)c.disconnect();} });
    }
    private void postJson(String path,String json,java.util.function.Consumer<String> ok,java.util.function.Consumer<String> fail){
        Executors.newSingleThreadExecutor().execute(() -> { HttpURLConnection c=null; try { URL u=new URL(BASE_URL+path); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/json; charset=UTF-8"); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(json.getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); String body=read(c,code>=400?c.getErrorStream():c.getInputStream()); if(code>=400)throw new IOException(body); runOnUiThread(()->ok.accept(body)); } catch(Exception e){runOnUiThread(()->fail.accept(e.getMessage()==null?"error":e.getMessage()));} finally{if(c!=null)c.disconnect();} });
    }
    private String read(HttpURLConnection c,InputStream in)throws IOException{if(in==null)return"";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);return s.toString();}}
    @Override protected void onResume(){super.onResume();updateLockStatus();}
    @Override protected void onDestroy(){super.onDestroy();if(poller!=null)poller.shutdownNow();}
}
